import type { Metadata } from "next";
import "./globals.css";

import { Inter } from "next/font/google";
import Image from "next/image";
import Link from "next/link";
import Providers from "./providers";
import HeaderAuthClient from "@/components/HeaderAuthClient";

export const metadata: Metadata = {
  title: "BIOFIN Dashboard",
  description: "Unlocking finance to protect and restore biodiversity",
};

const inter = Inter({
  subsets: ["latin"],
  display: "swap",
  variable: "--font-main",
});

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html className={inter.variable} lang="en" suppressHydrationWarning>
      <body>
        <Providers>
          <div className="appShell">
            <header className="header">
              <div className="headerInner">
                <Link href="/" className="brand">
                  <Image
                    src="/biofin_logo.png"
                    alt="BIOFIN Logo"
                    width={40}
                    height={40}
                    priority
                    className="logo"
                  />
                  <div className="brandText">
                    <div className="brandTitle">BIOFIN Dashboard</div>
                    <div className="brandSubtitle">
                      Unlocking finance to protect and restore biodiversity
                    </div>
                  </div>
                </Link>

                <div className="headerRight">
                  <nav className="nav" aria-label="Primary">
                    <Link className="navLink" href="/">
                      Home
                    </Link>
                    <Link className="navLink" href="/forms">
                      Forms
                    </Link>
                    <Link className="navCta" href="/dashboard">
                      Dashboard
                    </Link>
                  </nav>

                  <HeaderAuthClient />
                </div>
              </div>
            </header>

            <main className="main">
              <div className="container">
                <div className="pageCard">
                  <div className="pageGlow" aria-hidden="true" />
                  <div className="pageContent">{children}</div>
                </div>
              </div>
            </main>

            <footer className="footer">
              <div className="container footerInner">
                <p className="footerText">
                  Funded by the European Union. Views and opinions expressed are
                  however those of the author(s) only and do not necessarily
                  reflect those of the European Union or the European Research
                  Executive Agency (REA). Neither the European Union nor the
                  granting authority can be held responsible for them.
                </p>
                <div className="footerMeta">
                  © {new Date().getFullYear()} BIOFIN-EU. All rights reserved.
                </div>
              </div>
            </footer>
          </div>
        </Providers>
      </body>
    </html>
  );
}
